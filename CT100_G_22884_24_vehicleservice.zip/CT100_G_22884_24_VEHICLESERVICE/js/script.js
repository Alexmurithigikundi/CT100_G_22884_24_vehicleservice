/* =========================================================
   AutoCare Garage - script.js
   Handles: validation, dynamic updates, cost calculator
   ========================================================= */

// ---------- Grab elements once (cleaner and faster) ----------
const form         = document.getElementById("serviceForm");
const checkboxes   = document.querySelectorAll('input[name="services[]"]');
const vehicleType  = document.getElementById("vehicleType");
const yearInput    = document.getElementById("year");
const resetBtn     = document.getElementById("resetBtn");

// ---------- Settings ----------
const OLD_VEHICLE_AGE = 15;     // vehicles older than this get a warning
const MIN_YEAR = 1980;          // earliest "reasonable" year

// Info shown for each vehicle type (Task 3)
const vehicleInfo = {
  "Saloon Car": "Saloon cars: standard service bays are available, usually ready the same day.",
  "SUV":        "SUVs: heavier vehicles, so brake and alignment checks take a little longer.",
  "Pickup":     "Pickups: please tell us if you regularly carry heavy loads.",
  "Van":        "Vans: please book early, as van servicing needs the large bay."
};

/* ---------------------------------------------------------
   TASK 4: Calculate the estimated cost from ticked services
   --------------------------------------------------------- */
function calculateServiceCost() {
  let total = 0;
  checkboxes.forEach(function (box) {
    if (box.checked) {
      total += Number(box.dataset.price); // read data-price from the HTML
    }
  });
  document.getElementById("totalCost").textContent = "KSh " + total.toLocaleString("en-US");
  return total;
}

/* ---------------------------------------------------------
   TASK 3: Show list and number of selected services
   --------------------------------------------------------- */
function updateSelectedServices() {
  const list = document.getElementById("selectedList");
  list.innerHTML = "";               // clear old list
  let count = 0;

  checkboxes.forEach(function (box) {
    if (box.checked) {
      count++;
      const li = document.createElement("li");
      li.textContent = box.value + " (KSh " + Number(box.dataset.price).toLocaleString("en-US") + ")";
      list.appendChild(li);
    }
  });
  document.getElementById("serviceCount").textContent = count;
}

/* ---------------------------------------------------------
   TASK 3: Show info according to the selected vehicle type
   --------------------------------------------------------- */
function showVehicleInfo() {
  const box = document.getElementById("vehicleTypeInfo");
  const info = vehicleInfo[vehicleType.value];
  box.innerHTML = info ? '<div class="info-box">' + info + "</div>" : "";
}

/* ---------------------------------------------------------
   TASK 3: Warn about older vehicles
   --------------------------------------------------------- */
function checkVehicleAge() {
  const box = document.getElementById("ageWarning");
  const year = Number(yearInput.value);
  const currentYear = new Date().getFullYear();

  if (year >= MIN_YEAR && year <= currentYear && (currentYear - year) > OLD_VEHICLE_AGE) {
    box.innerHTML = '<div class="warning">Warning: this vehicle is over ' + OLD_VEHICLE_AGE +
                    ' years old. We recommend a Computer Diagnosis and Brake Inspection.</div>';
  } else {
    box.innerHTML = "";
  }
}

// Combined refresh used whenever a service is ticked/unticked
function refreshServiceSummary() {
  updateSelectedServices();
  calculateServiceCost();
}

/* ---------------------------------------------------------
   TASK 2: Validation helpers
   --------------------------------------------------------- */
function showError(fieldId, message) {
  document.getElementById(fieldId + "Error").textContent = message;
}

function clearErrors() {
  document.querySelectorAll(".error").forEach(function (span) { span.textContent = ""; });
}

/* ---------------------------------------------------------
   TASK 2: Validate the whole form
   Returns true  -> form is submitted
   Returns false -> form is blocked
   --------------------------------------------------------- */
function validateServiceForm() {
  clearErrors();
  let valid = true;

  const name   = document.getElementById("customerName").value.trim();
  const phone  = document.getElementById("phone").value.trim();
  const email  = document.getElementById("email").value.trim();
  const regNo  = document.getElementById("regNo").value.trim();
  const type   = vehicleType.value;
  const model  = document.getElementById("vehicleModel").value.trim();
  const year   = Number(yearInput.value);
  const date   = document.getElementById("serviceDate").value;
  const currentYear = new Date().getFullYear();

  // 1. Customer name provided
  if (name === "") { showError("customerName", "Please enter the customer name."); valid = false; }

  // 2. Phone: exactly 10 digits (regex: ^ start, \d digit, {10} ten times, $ end)
  if (!/^\d{10}$/.test(phone)) { showError("phone", "Phone number must contain exactly 10 digits."); valid = false; }

  // 3. Valid email
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showError("email", "Please enter a valid email address."); valid = false; }

  // 4. Registration number provided
  if (regNo === "") { showError("regNo", "Please enter the vehicle registration number."); valid = false; }

  // Vehicle type and model
  if (type === "")  { showError("vehicleType", "Please select a vehicle type."); valid = false; }
  if (model === "") { showError("vehicleModel", "Please enter the vehicle model."); valid = false; }

  // 5. Year is reasonable
  if (!Number.isInteger(year) || year < MIN_YEAR || year > currentYear) {
    showError("year", "Enter a valid year between " + MIN_YEAR + " and " + currentYear + "."); valid = false;
  }

  // Service date
  if (date === "") { showError("serviceDate", "Please choose a preferred service date."); valid = false; }

  // 6. At least one service selected
  if (document.querySelectorAll('input[name="services[]"]:checked').length === 0) {
    showError("services", "Please select at least one service."); valid = false;
  }

  // 7. Messages were displayed above via showError()
  return valid;
}

/* =========================================================
   TASK 5: EVENTS (change, input, click, submit)
   ========================================================= */
// change: ticking/unticking a service -> update list, count, total
checkboxes.forEach(function (box) {
  box.addEventListener("change", refreshServiceSummary);
});

// change: choosing a vehicle type -> show info
vehicleType.addEventListener("change", showVehicleInfo);

// input: typing the year -> check age live
yearInput.addEventListener("input", checkVehicleAge);

// click: clear button -> reset the dynamic parts too
resetBtn.addEventListener("click", function () {
  // wait a moment so the form is cleared first, then refresh the display
  setTimeout(function () {
    clearErrors();
    refreshServiceSummary();
    showVehicleInfo();
    checkVehicleAge();
  }, 0);
});

// submit: extra log (the real blocking is done by onsubmit in the HTML)
form.addEventListener("submit", function () {
  console.log("Form submit event fired");
});

// Don't allow past dates in the date picker
document.getElementById("serviceDate").min = new Date().toISOString().split("T")[0];