<?php
// process_service.php - receives, validates and confirms a service booking

// If someone opens this file directly (not via the form), send them back
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: service.html");
    exit;
}

// Server-side price list (the PHP's own trusted copy)
$prices = [
    "Engine Oil Change"  => 3000,
    "Brake Inspection"   => 2000,
    "Wheel Alignment"    => 2500,
    "Computer Diagnosis" => 3500,
    "Full Service"       => 8000,
    "Tyre Balancing"     => 2000   // individual requirement (last digit 4)
];
$allowedTypes = ["Saloon Car", "SUV", "Pickup", "Van"];

// Retrieve submitted data (trim spaces, and make safe for display)
function clean($value) {
    return htmlspecialchars(trim($value ?? ""));
}
$name    = clean($_POST["customerName"] ?? "");
$phone   = clean($_POST["phone"] ?? "");
$email   = clean($_POST["email"] ?? "");
$regNo   = clean($_POST["regNo"] ?? "");
$type    = clean($_POST["vehicleType"] ?? "");
$model   = clean($_POST["vehicleModel"] ?? "");
$year    = (int) ($_POST["year"] ?? 0);
$date    = trim($_POST["serviceDate"] ?? "");
$selected = $_POST["services"] ?? [];

// ---------- Server-side validation ----------
$errors = [];
if ($name === "")                                   $errors[] = "Customer name is required.";
if (!preg_match('/^\d{10}$/', $phone))              $errors[] = "Phone number must be exactly 10 digits.";
if (!filter_var($email, FILTER_VALIDATE_EMAIL))     $errors[] = "A valid email address is required.";
if ($regNo === "")                                  $errors[] = "Vehicle registration number is required.";
if (!in_array($type, $allowedTypes))                $errors[] = "Please select a valid vehicle type.";
if ($model === "")                                  $errors[] = "Vehicle model is required.";
if ($year < 1980 || $year > (int) date("Y"))        $errors[] = "Year of manufacture is not reasonable.";
if ($date === "" || !strtotime($date))              $errors[] = "A valid service date is required.";
if (!is_array($selected) || count($selected) === 0) $errors[] = "Select at least one service.";

// Calculate total independently
$total = 0;
$validServices = [];
if (is_array($selected)) {
    foreach ($selected as $service) {
        if (isset($prices[$service])) {       // only accept services we know
            $total += $prices[$service];
            $validServices[] = $service;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Service Booking Confirmation</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <h1>AutoCare Garage</h1>
    <nav><a href="index.html">Home</a><a href="service.html">Book a Service</a></nav>
  </header>

  <div class="container">
  <?php if (!empty($errors)): ?>
    <div class="card">
      <h2 style="color:#c0392b;">Booking Failed</h2>
      <ul>
        <?php foreach ($errors as $e): ?>
          <li><?php echo $e; ?></li>
        <?php endforeach; ?>
      </ul>
      <a class="btn" href="service.html">Go Back</a>
    </div>

  <?php else: ?>
<pre>
SERVICE REQUEST RECEIVED

Customer: <?php echo $name; ?>

Phone: <?php echo $phone; ?>

Email: <?php echo $email; ?>

Vehicle: <?php echo $regNo; ?>

Vehicle Type: <?php echo $type; ?>

Model: <?php echo $model; ?> (<?php echo $year; ?>)
Service Date: <?php echo date("d F Y", strtotime($date)); ?>


Selected Services:
<?php foreach ($validServices as $s) { echo $s . " - KSh " . number_format($prices[$s]) . "\n"; } ?>

ESTIMATED SERVICE COST: KSh <?php echo number_format($total); ?>
</pre>
      <a class="btn" href="service.html">Book Another Service</a>
  <?php endif; ?>
  </div>
</body>
</html>