<?php
/* ================================================================
   process.php - Server-side validation, fee calculation, confirmation
   ================================================================ */

/* ---------- Fee constants (KSh) - same values as script.js ---------- */
const REGISTRATION_FEE    = 1000;
const ATTENDANCE_PER_DAY  = 500;
const WORKSHOP_WEB_FEE    = 750;
const WORKSHOP_MOBILE_FEE = 1000;   // individualized requirement: second workshop
const LUNCH_PER_DAY       = 300;

/* ---------- Helper: read a text field safely ---------- */
function getField($key)
{
    if (isset($_POST[$key]) && is_string($_POST[$key])) {
        return trim($_POST[$key]);
    }
    return "";
}

$errors = [];

/* ---------- Check the page was reached by form submission ---------- */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    $errors[] = "No registration data received. Please use the registration form.";
} else {

    /* ---------- Receive the values ---------- */
    $fullName    = getField("full_name");
    $admissionNo = getField("admission_no");
    $email       = getField("email");
    $phone       = getField("phone");
    $year        = getField("year");
    $category    = getField("category");
    $daysRaw     = getField("days");
    $meal        = getField("meal");

    $webSelected    = (getField("workshop_web") === "yes");
    $mobileSelected = (getField("workshop_mobile") === "yes");

    /* ---------- Server-side validation ---------- */
    if ($fullName === "") {
        $errors[] = "Full name is required.";
    }
    if ($admissionNo === "") {
        $errors[] = "Admission number is required.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email address is not valid.";
    }
    if (!preg_match('/^\d{10}$/', $phone)) {
        $errors[] = "Phone number must contain exactly 10 digits.";
    }
    if (!in_array($year, ["1", "2", "3", "4"], true)) {
        $errors[] = "Year of study is not valid.";
    }

    $categoryLabels = [
        "conference_only" => "Conference Only",
        "workshop"        => "Workshop Participant"
    ];
    if (!array_key_exists($category, $categoryLabels)) {
        $errors[] = "Please select a valid participation category.";
    }

    $days = filter_var($daysRaw, FILTER_VALIDATE_INT,
                       ["options" => ["min_range" => 1, "max_range" => 3]]);
    if ($days === false) {
        $errors[] = "Number of days must be a whole number from 1 to 3.";
    }

    if ($meal !== "yes" && $meal !== "no") {
        $errors[] = "Please choose a meal option.";
    }
}

/* ---------- Calculate the fee (only if everything is valid) ---------- */
if (empty($errors)) {

    // Workshops count ONLY for Workshop Participants
    if ($category !== "workshop") {
        $webSelected    = false;
        $mobileSelected = false;
    }

    $workshopFee   = 0;
    $workshopNames = [];
    if ($webSelected) {
        $workshopFee += WORKSHOP_WEB_FEE;
        $workshopNames[] = "Web Development";
    }
    if ($mobileSelected) {
        $workshopFee += WORKSHOP_MOBILE_FEE;
        $workshopNames[] = "Mobile App Development";
    }
    $workshopText = empty($workshopNames) ? "None" : implode(", ", $workshopNames);

    $attendanceFee = $days * ATTENDANCE_PER_DAY;
    $mealFee       = ($meal === "yes") ? $days * LUNCH_PER_DAY : 0;

    // Total = Registration + Attendance + Workshop + Meals
    $totalFee = REGISTRATION_FEE + $attendanceFee + $workshopFee + $mealFee;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Confirmation</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Student Technology and Innovation Conference</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="register.html">Register</a>
        </nav>
    </header>

    <main>
        <section class="form-card">

        <?php if (!empty($errors)): ?>

            <h2 class="error-title">REGISTRATION FAILED</h2>
            <ul class="error-list">
                <?php foreach ($errors as $message): ?>
                    <li><?php echo htmlspecialchars($message); ?></li>
                <?php endforeach; ?>
            </ul>
            <a class="btn" href="register.html">Go back to the form</a>

        <?php else: ?>

            <h2 class="success-title">REGISTRATION SUCCESSFUL</h2>
            <table class="summary">
                <tr><th>Participant</th>
                    <td><?php echo htmlspecialchars($fullName); ?></td></tr>
                <tr><th>Admission Number</th>
                    <td><?php echo htmlspecialchars($admissionNo); ?></td></tr>
                <tr><th>Email</th>
                    <td><?php echo htmlspecialchars($email); ?></td></tr>
                <tr><th>Phone</th>
                    <td><?php echo htmlspecialchars($phone); ?></td></tr>
                <tr><th>Year of Study</th>
                    <td>Year <?php echo htmlspecialchars($year); ?></td></tr>
                <tr><th>Category</th>
                    <td><?php echo htmlspecialchars($categoryLabels[$category]); ?></td></tr>
                <tr><th>Conference Days</th>
                    <td><?php echo $days; ?></td></tr>
                <tr><th>Workshop(s)</th>
                    <td><?php echo htmlspecialchars($workshopText); ?></td></tr>
                <tr><th>Meals</th>
                    <td><?php echo ($meal === "yes") ? "Yes" : "No"; ?></td></tr>
            </table>

            <h3>Fee Breakdown</h3>
            <table class="summary">
                <tr><th>Registration fee</th>
                    <td>KSh <?php echo number_format(REGISTRATION_FEE); ?></td></tr>
                <tr><th>Attendance (<?php echo $days; ?> x <?php echo ATTENDANCE_PER_DAY; ?>)</th>
                    <td>KSh <?php echo number_format($attendanceFee); ?></td></tr>
                <tr><th>Workshops</th>
                    <td>KSh <?php echo number_format($workshopFee); ?></td></tr>
                <tr><th>Meals</th>
                    <td>KSh <?php echo number_format($mealFee); ?></td></tr>
            </table>

            <div class="fee-box">
                TOTAL AMOUNT PAYABLE: <strong>KSh <?php echo number_format($totalFee); ?></strong>
            </div>

            <p>Thank you for registering for the Student Technology and Innovation Conference.</p>

        <?php endif; ?>

        </section>
    </main>

    <footer>
        <p>&copy; 2026 Student Technology and Innovation Conference</p>
    </footer>
</body>
</html>