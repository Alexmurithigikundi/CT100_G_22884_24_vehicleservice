/* ================================================================
   script.js - Client-side logic for the registration page
   ================================================================ */

/* ---------- Fee constants (KSh). Change prices here only. ---------- */
const REGISTRATION_FEE    = 1000;
const ATTENDANCE_PER_DAY  = 500;
const WORKSHOP_WEB_FEE    = 750;
const WORKSHOP_MOBILE_FEE = 1000;   // individualized requirement: second workshop
const LUNCH_PER_DAY       = 300;

/* ---------- Helper functions for error messages ---------- */
function showError(errorId, message) {
    document.getElementById(errorId).textContent = message;
}

function clearError(errorId) {
    document.getElementById(errorId).textContent = "";
}

/* ---------- Task 2: Form validation ---------- */
function validateForm() {
    let isValid = true;

    const fullName    = document.getElementById("fullName").value.trim();
    const admissionNo = document.getElementById("admissionNo").value.trim();
    const email       = document.getElementById("email").value.trim();
    const phone       = document.getElementById("phone").value.trim();
    const daysValue   = document.getElementById("days").value;
    const category    = document.getElementById("category").value;

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phonePattern = /^\d{10}$/;

    if (fullName === "") {
        showError("fullNameError", "Full name cannot be empty.");
        isValid = false;
    } else {
        clearError("fullNameError");
    }

    if (admissionNo === "") {
        showError("admissionNoError", "Admission number is required.");
        isValid = false;
    } else {
        clearError("admissionNoError");
    }

    if (!emailPattern.test(email)) {
        showError("emailError", "Enter a valid email, e.g. mary@example.com.");
        isValid = false;
    } else {
        clearError("emailError");
    }

    if (!phonePattern.test(phone)) {
        showError("phoneError", "Phone number must contain exactly 10 digits.");
        isValid = false;
    } else {
        clearError("phoneError");
    }

    const days = Number(daysValue);
    if (!Number.isInteger(days) || days < 1 || days > 3) {
        showError("daysError", "Number of days must be between 1 and 3.");
        isValid = false;
    } else {
        clearError("daysError");
    }

    if (category === "") {
        showError("categoryError", "Please select a participation category.");
        isValid = false;
    } else {
        clearError("categoryError");
    }

    return isValid;
}

/* ---------- Task 3: Dynamic form behaviour ---------- */
function updateForm() {
    const category        = document.getElementById("category").value;
    const workshopSection = document.getElementById("workshopSection");
    const packageMessage  = document.getElementById("packageMessage");

    if (category === "workshop") {
        workshopSection.classList.remove("hidden");
        packageMessage.textContent =
            "Package: Workshop Participant - conference attendance plus workshop sessions.";
    } else if (category === "conference_only") {
        hideWorkshops();
        packageMessage.textContent =
            "Package: Conference Only - attendance without workshops.";
    } else {
        hideWorkshops();
        packageMessage.textContent = "";
    }

    calculateFee();
}

function hideWorkshops() {
    document.getElementById("workshopSection").classList.add("hidden");
    document.getElementById("workshopWeb").checked    = false;
    document.getElementById("workshopMobile").checked = false;
}

/* ---------- Task 4: Conference fee calculator ---------- */
function calculateFee() {
    let days = Number(document.getElementById("days").value);
    if (!Number.isInteger(days) || days < 1 || days > 3) {
        days = 0;
    }

    let workshopFee = 0;
    if (document.getElementById("workshopWeb").checked) {
        workshopFee += WORKSHOP_WEB_FEE;
    }
    if (document.getElementById("workshopMobile").checked) {
        workshopFee += WORKSHOP_MOBILE_FEE;
    }

    const mealChoice = document.querySelector('input[name="meal"]:checked').value;
    let mealFee = 0;
    if (mealChoice === "yes") {
        mealFee = days * LUNCH_PER_DAY;
    }

    const attendanceFee = days * ATTENDANCE_PER_DAY;
    const totalFee = REGISTRATION_FEE + attendanceFee + workshopFee + mealFee;

    document.getElementById("totalFee").textContent =
        "KSh " + totalFee.toLocaleString("en-US");
}

/* ---------- Task 5: Attaching events ---------- */
document.getElementById("registrationForm").addEventListener("submit", function (event) {
    if (!validateForm()) {
        event.preventDefault();
    }
});

document.getElementById("category").addEventListener("change", updateForm);
document.getElementById("days").addEventListener("input", calculateFee);
document.getElementById("workshopWeb").addEventListener("click", calculateFee);
document.getElementById("workshopMobile").addEventListener("click", calculateFee);

document.querySelectorAll('input[name="meal"]').forEach(function (radio) {
    radio.addEventListener("click", calculateFee);
});

/* ---------- Run once on page load ---------- */
calculateFee();